package com.student.library

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

private val Ink = Color(0xFF232624)
private val Green = Color(0xFF176B57)
private val Pale = Color(0xFFF7F5F1)
private val Mint = Color(0xFFE4F1EC)

data class LibraryFile(val id:String, val title:String, val subtitle:String, val type:String, val url:String)

private val library = listOf(
    LibraryFile("islamic-culture", "الثقافة الإسلامية", "كتاب", "كتاب", "https://1drv.ms/b/c/2afc65be631f65ed/IQDK2lHTonDiTZOLKF5FJFBpASw7eKWe3ZwD4AhV2ipeDA4"),
    LibraryFile("acc-01", "معادلة المحاسبة", "المحاضرة الأولى", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQBslTK34IynTZtGmvG-2OFfAcBozzqpoHMdQytUpJ1-TR0"),
    LibraryFile("acc-02", "تطبيقات معادلة الميزانية", "المحاضرة الثانية", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQDGxdEwonUpRbqHGqL_AmPbAYgxd4Qt3Nii3Jb3ymjFU8Q"),
    LibraryFile("acc-03", "تكملة معادلة المحاسبة + قاعدة الحسابات", "المحاضرة الثالثة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQArFb0wVmGDSLOPXs42no_yAXFe_cnTdM-oehyElNl1tzY"),
    LibraryFile("acc-04", "قاعدة القيد المزدوج ومراحل الدورة المحاسبية", "المحاضرة الرابعة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQCwp-knihZAS5kSwmiRmN-kAeBwRIUsXW1cr92em0hMoyM"),
    LibraryFile("acc-05", "عمليات رأس المال والمسحوبات والأصول الثابتة", "المحاضرة الخامسة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQDum0xQV-TKSaMtoW7ZoaTWAa4oKZlYOZHjbeu2hFsphfM"),
    LibraryFile("acc-06", "القروض + النقدية", "المحاضرة السادسة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQAIDJYLXeeOT5ZFv77fJU8jAQuSMKQlVwpSILkfnN7OoMA"),
    LibraryFile("acc-07", "تكملة صندوق النثريات + عمليات البنك", "المحاضرة السابعة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQBHG-cZgX_SS7QcylzhTN4sAUkhUHIvgZQiYTy-gv6sqs8"),
    LibraryFile("acc-08", "مذكرة تسوية البنوك", "المحاضرة الثامنة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQD69vNvMTRxRI673YSE8mOOASZ0lwHbCVP58tQwq1LvmTA"),
    LibraryFile("acc-09", "عمليات الشراء والبيع", "المحاضرة التاسعة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQCUTb1YKjI7QanAG8GeEp0JAcbHVtsqrIH4hoJ7UrgR7no"),
    LibraryFile("acc-10", "الأخطاء المحاسبية وكيفية تصحيحها", "المحاضرة العاشرة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQBQJiHk-VKdQ4Ewla8lG-1tAaVGRf-6YrArpre031UqEwY"),
    LibraryFile("acc-11", "القوائم المالية", "المحاضرة الحادية عشرة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQCMdApq8k3_QZ5Anm-Rv9r5AT60QVsYYYqbfZ4yN0kcqi0"),
    LibraryFile("acc-12", "ملحق النظري في المحاسبة", "المحاضرة الثانية عشرة", "محاضرة", "https://1drv.ms/b/c/2afc65be631f65ed/IQC3t_oDbudNTZUvQfTU5y6xAXzzTis5JbFEGay7AIQn0UE"),
    LibraryFile("management", "مبادئ الإدارة", "ملزمة", "ملزمة", "https://1drv.ms/b/c/2afc65be631f65ed/IQAu2IafU-6ZQIZDOgqZ1d_GASGoxtuKBXl54BixnJfO4Q0")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable fun App() {
    MaterialTheme(colorScheme = lightColorScheme(primary=Green, background=Pale, surface=Color.White)) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
            var screen by remember { mutableStateOf("departments") }
            var selected by remember { mutableStateOf<LibraryFile?>(null) }
            BackHandler(screen != "departments") { screen = when(screen) { "reader" -> "files"; "files" -> "levels"; "levels" -> "departments"; else -> "departments" } }
            when(screen) {
                "departments" -> Departments { screen="levels" }
                "levels" -> Levels(onBack={screen="departments"}) { screen="files" }
                "files" -> FilesScreen(onBack={screen="levels"}) { selected=it; screen="reader" }
                "reader" -> selected?.let { ReaderScreen(it) { screen="files" } }
            }
        }
    }
}

@Composable fun Header(title:String, subtitle:String?=null, onBack:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=18.dp), verticalAlignment=Alignment.CenterVertically) {
        if(onBack!=null) IconButton(onClick=onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع", tint=Ink) }
        Column(Modifier.weight(1f)) { Text(title, fontSize=24.sp, fontWeight=FontWeight.Bold, color=Ink); if(subtitle!=null) Text(subtitle, color=Color.Gray, fontSize=14.sp) }
        Box(Modifier.size(42.dp).background(Mint, RoundedCornerShape(12.dp)), contentAlignment=Alignment.Center) { Icon(Icons.Rounded.MenuBook, null, tint=Green) }
    }
}

@Composable fun Departments(onOpen:()->Unit) { Scaffold(containerColor=Pale) { p -> Column(Modifier.padding(p)) {
    Header("مكتبة طلاب كلية العلوم المالية والمصرفية عبس", "كتبك ومحاضراتك في مكان واحد")
    Text("اختر القسم", Modifier.padding(horizontal=20.dp, vertical=16.dp), fontWeight=FontWeight.SemiBold, color=Ink)
    ElevatedCard(onClick=onOpen, modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp), shape=RoundedCornerShape(16.dp), colors=CardDefaults.elevatedCardColors(containerColor=Color.White)) {
        Row(Modifier.padding(20.dp), verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(52.dp).background(Mint, RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center){Icon(Icons.Rounded.School,null,tint=Green)}; Spacer(Modifier.width(16.dp)); Column(Modifier.weight(1f)){Text("القسم العام", fontWeight=FontWeight.Bold, fontSize=18.sp); Text("المستوى الأول", color=Color.Gray)}; Icon(Icons.Rounded.ChevronLeft,null,tint=Green) }
    }
} } }

@Composable fun Levels(onBack:()->Unit,onOpen:()->Unit) { Scaffold(containerColor=Pale) { p -> Column(Modifier.padding(p)) { Header("القسم العام", "اختر المستوى",onBack); ElevatedCard(onClick=onOpen, modifier=Modifier.fillMaxWidth().padding(20.dp), shape=RoundedCornerShape(16.dp), colors=CardDefaults.elevatedCardColors(containerColor=Color.White)){ Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically){ Text("١",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Green); Spacer(Modifier.width(18.dp)); Column(Modifier.weight(1f)){Text("المستوى الأول",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("١٤ ملفاً متاحاً",color=Color.Gray)};Icon(Icons.Rounded.ChevronLeft,null,tint=Green)}} } } }

@Composable fun FilesScreen(onBack:()->Unit,onOpen:(LibraryFile)->Unit) {
    val context=LocalContext.current; val scope=rememberCoroutineScope(); var filter by remember{mutableStateOf("الكل")}; var version by remember{mutableIntStateOf(0)}; var downloading by remember{mutableStateOf<String?>(null)}; var error by remember{mutableStateOf<String?>(null)}
    val shown=if(filter=="الكل") library else library.filter{it.type==filter}
    Scaffold(containerColor=Pale) { p -> Column(Modifier.padding(p)) { Header("المستوى الأول","القسم العام",onBack)
        ScrollableTabRow(selectedTabIndex=listOf("الكل","كتاب","محاضرة","ملزمة").indexOf(filter), containerColor=Pale, edgePadding=20.dp, divider={}) { listOf("الكل","كتاب","محاضرة","ملزمة").forEach { Tab(selected=filter==it,onClick={filter=it},text={Text(it)}) } }
        error?.let { Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(20.dp)) }
        LazyColumn(contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) { items(shown,key={it.id}) { item ->
            val local=File(context.filesDir,"pdfs/${item.id}.pdf"); val downloaded=local.exists() && version>=0
            ElevatedCard(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.elevatedCardColors(containerColor=Color.White)) { Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){ Box(Modifier.size(46.dp).background(if(downloaded) Mint else Color(0xFFF0EFED),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(if(downloaded) Icons.Rounded.DownloadDone else Icons.Rounded.PictureAsPdf,null,tint=if(downloaded) Green else Color.Gray)}; Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)){Text(item.title,fontWeight=FontWeight.SemiBold,color=Ink);Text(item.subtitle,color=Color.Gray,fontSize=13.sp)}
                if(downloading==item.id) CircularProgressIndicator(Modifier.size(26.dp),strokeWidth=3.dp)
                else if(downloaded) { IconButton(onClick={onOpen(item)}){Icon(Icons.Rounded.MenuBook,"فتح",tint=Green)}; IconButton(onClick={local.delete();version++}){Icon(Icons.Rounded.DeleteOutline,"حذف",tint=Color(0xFFE05D4E))} }
                else FilledTonalIconButton(onClick={downloading=item.id;error=null;scope.launch{ runCatching{downloadPdf(item.url,local)}.onFailure{error="تعذر تحميل ${item.title}: تأكد من الإنترنت وصلاحية الرابط"};downloading=null;version++ }}){Icon(Icons.Rounded.Download,"تحميل")}
            } }
        } }
    } }
}

private suspend fun downloadPdf(url:String,target:File)=withContext(Dispatchers.IO){
    target.parentFile?.mkdirs(); val direct=if(url.contains("?")) "$url&download=1" else "$url?download=1"; val client=OkHttpClient.Builder().followRedirects(true).build(); val response=client.newCall(Request.Builder().url(direct).build()).execute(); if(!response.isSuccessful) error("HTTP ${response.code}"); val body=response.body ?: error("Empty response"); val temp=File(target.parentFile,"${target.name}.part"); body.byteStream().use{input->FileOutputStream(temp).use{input.copyTo(it)}}; val head=ByteArray(4); temp.inputStream().use{it.read(head)}; if(String(head)!="%PDF"){temp.delete();error("الرابط لم يرجع ملف PDF")}; if(!temp.renameTo(target)) error("تعذر حفظ الملف")
}

@Composable fun ReaderScreen(item:LibraryFile,onBack:()->Unit){
    val context=LocalContext.current; val file=File(context.filesDir,"pdfs/${item.id}.pdf"); var page by remember{mutableIntStateOf(0)}; var pageCount by remember{mutableIntStateOf(1)}; var bitmap by remember{mutableStateOf<Bitmap?>(null)}
    LaunchedEffect(file,page){ bitmap=withContext(Dispatchers.IO){ ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{renderer->pageCount=renderer.pageCount;renderer.openPage(page.coerceIn(0,renderer.pageCount-1)).use{p->val scale=2f;Bitmap.createBitmap((p.width*scale).toInt(),(p.height*scale).toInt(),Bitmap.Config.ARGB_8888).also{b->b.eraseColor(android.graphics.Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)}}}} } }
    Scaffold(containerColor=Color(0xFF252525),topBar={Row(Modifier.fillMaxWidth().background(Color(0xFF1F1F1F)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.AutoMirrored.Rounded.ArrowBack,"رجوع",tint=Color.White)};Text(item.title,color=Color.White,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Text("${page+1} / $pageCount",color=Color.LightGray,modifier=Modifier.padding(12.dp))}},bottomBar={Row(Modifier.fillMaxWidth().background(Color(0xFF1F1F1F)).padding(8.dp),horizontalArrangement=Arrangement.SpaceEvenly){TextButton(enabled=page>0,onClick={page--}){Text("السابق")};TextButton(enabled=page<pageCount-1,onClick={page++}){Text("التالي")}}}) { p -> Box(Modifier.fillMaxSize().padding(p),contentAlignment=Alignment.Center){bitmap?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxSize().padding(8.dp))}?:CircularProgressIndicator()} }
}
